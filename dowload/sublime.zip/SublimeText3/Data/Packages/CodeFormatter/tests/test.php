<?php


while ($i <= 1):
    $html .= 'text';
endwhile;